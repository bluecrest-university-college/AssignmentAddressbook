package com.example.addressbook;

import android.app.AlertDialog;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

class userAdapter extends RecyclerView.Adapter<userAdapter.ViewHolder> {


    public userAdapter(ArrayList<String> users) {
        this.users = users;
    }

    ArrayList<String> users;

    @Override
    public ViewHolder onCreateViewHolder( ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(parent.getContext().inflate(R.layout.User_row,parent, false));
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder( userAdapter.ViewHolder viewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder( View itemView) {
            super(itemView);
        }
    }
}
