package com.example.addressbook;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class Activity2 extends AppCompatActivity {

    private static final String TAG = "Activity2";

    EditText fieldName;
    EditText fieldStreet;
    EditText fieldCity;
    EditText fieldState;
    EditText fieldZip;
    EditText fieldPhone;
    EditText fieldDate;

    private Button button;

    public static void getContext() {
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        fieldName = (EditText) findViewById(R.id.name);
        fieldStreet = (EditText) findViewById(R.id.street);
        fieldCity = (EditText) findViewById(R.id.city);
        fieldState = (EditText) findViewById(R.id.state);
        fieldZip = (EditText) findViewById(R.id.zip);
        fieldPhone = (EditText) findViewById(R.id.phone);
        fieldDate = (EditText) findViewById(R.id.date);


        button = (Button) findViewById(R.id.saveAddress);

        Spinner mySpinner = (Spinner) findViewById(R.id.contact_type);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(Activity2.this,
                android.R.layout.simple_expandable_list_item_1, getResources().getStringArray(R.array.contact_type));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);


    button.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //TODO : 1/03/19 save to database
            log.d(TAG, "onClick: Name: " + fieldName.getText().toString());
        }
    });

    }

}


/*  button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });
       */

 /*
    public void openActivity2(){

        Intent intent = new Intent (this,Activity2.class);

        startActivity(intent);

    }
    */