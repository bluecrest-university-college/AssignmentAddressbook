package com.example.addressbook;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

public class AddressBook extends RecyclerView.Adapter<AddressBook.ViewHolder> {

    private Context context;
    private List<Address> ListItems;

    public AddressBook(Context context, List listitem){

        this.context=context;
        this.ListItems=listitem;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(parent.get context())
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull AddressBook.ViewHolder viewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
