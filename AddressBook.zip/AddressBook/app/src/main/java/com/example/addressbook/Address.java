package com.example.addressbook;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;

public class Address extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
    }


    private String fieldName;
    private  String fieldStreet;
    private  String fieldCity;
    private  String fieldState;
    private int fieldZip;
    private int fieldPhone;
    private String fieldDate;

    public Address(String fieldName, String fieldStreet, String fieldCity, String fieldState, int fieldZip, int fieldPhone, String fieldDate) {
        this.fieldName = fieldName;
        this.fieldStreet = fieldStreet;
        this.fieldCity = fieldCity;
        this.fieldState = fieldState;
        this.fieldZip = fieldZip;
        this.fieldPhone = fieldPhone;
        this.fieldDate = fieldDate;
    }


    public String getFieldName() {
        return fieldName;
    }

    public String getFieldStreet() {
        return fieldStreet;
    }

    public String getFieldCity() {
        return fieldCity;
    }

    public String getFieldState() {
        return fieldState;
    }

    public int getFieldZip() {
        return fieldZip;
    }

    public int getFieldPhone() {
        return fieldPhone;
    }

    public String getFieldDate() {
        return fieldDate;
    }

}
