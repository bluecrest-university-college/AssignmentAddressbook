package com.example.addressbook;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button button2;
    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    ArrayList<String> users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView=findViewById(R.id.contentDisplay);

        users = new ArrayList<>();

        for (int i = 0; i < ; i++) {
            
        }

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter=new userAdapter(users);
        recyclerView.setAdapter(adapter);


        button2 = (Button) findViewById(R.id.addAddress);



    }



    public void loadActivity(View v){

        startActivity(new Intent(this, Activity2.class));
    }

}
