package com.example.addressbook;

public class Ext_person {
}
